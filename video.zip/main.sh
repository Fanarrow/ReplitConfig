!bin/bash
cd Pasta && yarn start